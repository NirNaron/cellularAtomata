public class cellularAutomata {

}
